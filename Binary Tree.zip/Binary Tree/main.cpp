#include "BinaryTree.hpp"

int main() {
    BinaryTree<int> tree;
    tree.insert(13);
    tree.insert(7);
    tree.insert(3);
    tree.insert(10);
    tree.insert(8);
    tree.insert(19);
    tree.insert(15);
    tree.insert(23);
    tree.insert(22);

    BinaryTree<char> tree2;
    tree2.insert('a');
    tree2.insert('d');
    tree2.insert('b');
    tree2.insert('e');
    tree2.insert('f');
    tree2.insert('c');

    BinaryTree<string> tree3;
    tree3.insert("Tessema");
    tree3.insert("Maireg");
    tree3.insert("Bogale");
    tree3.insert("Mulat");

    tree.inOrderTraversal();
    tree2.inOrderTraversal();
    tree3.inOrderTraversal();

    return 0;
}
